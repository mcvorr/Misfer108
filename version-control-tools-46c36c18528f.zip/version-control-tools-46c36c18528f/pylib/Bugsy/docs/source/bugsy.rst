.. toctree::
   :maxdepth: 2

:mod:`Bugsy`
---------------------
.. automodule:: bugsy
.. autoclass:: Bugsy
   :members:
   :special-members:
.. autoclass:: BugsyException
   :members:
.. autoclass:: LoginException
   :members:
