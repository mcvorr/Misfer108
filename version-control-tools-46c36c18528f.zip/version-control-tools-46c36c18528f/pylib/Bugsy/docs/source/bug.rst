.. toctree::
   :maxdepth: 2

:mod:`Bug`
---------------------
.. automodule:: bugsy
.. autoclass:: Bug
   :members:
   :special-members:
.. autoclass:: BugException
   :members:
