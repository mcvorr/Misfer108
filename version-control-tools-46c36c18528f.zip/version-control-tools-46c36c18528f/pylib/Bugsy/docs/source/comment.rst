.. toctree::
   :maxdepth: 2

:mod:`Comment`
---------------------
.. versionchanged:: 0.3
.. automodule:: bugsy
.. autoclass:: Comment
   :members: