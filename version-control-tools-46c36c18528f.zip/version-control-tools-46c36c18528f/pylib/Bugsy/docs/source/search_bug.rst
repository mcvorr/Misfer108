.. toctree::
   :maxdepth: 2

:mod:`Search`
---------------------
.. versionchanged:: 0.2
.. automodule:: bugsy
.. autoclass:: Search
   :members:
   :special-members:
