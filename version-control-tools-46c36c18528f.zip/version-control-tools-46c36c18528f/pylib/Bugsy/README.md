Bugsy
=====
[![Build Status](https://travis-ci.org/AutomatedTester/Bugsy.svg?branch=master)](https://travis-ci.org/AutomatedTester/Bugsy)
[![Coverage Status](https://coveralls.io/repos/AutomatedTester/Bugsy/badge.svg?branch=master)](https://coveralls.io/r/AutomatedTester/Bugsy?branch=master)


Bugsy is a library for interacting with the native REST API for Bugzilla.

Documentation can be found on [Read The Docs](http://bugsy.readthedocs.org/en/latest)
