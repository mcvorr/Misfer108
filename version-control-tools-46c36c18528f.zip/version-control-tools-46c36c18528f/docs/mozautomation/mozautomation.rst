mozautomation package
=====================

Submodules
----------

mozautomation.bugzilla module
-----------------------------

.. automodule:: mozautomation.bugzilla
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.buildbotdata module
---------------------------------

.. automodule:: mozautomation.buildbotdata
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.buildstatus module
--------------------------------

.. automodule:: mozautomation.buildstatus
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.changetracker module
----------------------------------

.. automodule:: mozautomation.changetracker
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.commitparser module
---------------------------------

.. automodule:: mozautomation.commitparser
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.firefoxprofile module
-----------------------------------

.. automodule:: mozautomation.firefoxprofile
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.releases module
-----------------------------

.. automodule:: mozautomation.releases
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.repository module
-------------------------------

.. automodule:: mozautomation.repository
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.selfserve module
------------------------------

.. automodule:: mozautomation.selfserve
    :members:
    :undoc-members:
    :show-inheritance:

mozautomation.treestatus module
-------------------------------

.. automodule:: mozautomation.treestatus
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mozautomation
    :members:
    :undoc-members:
    :show-inheritance:
