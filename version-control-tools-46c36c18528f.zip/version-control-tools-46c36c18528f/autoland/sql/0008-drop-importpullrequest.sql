drop table MozreviewPullRequest;
