Place all plugins to be synced here
