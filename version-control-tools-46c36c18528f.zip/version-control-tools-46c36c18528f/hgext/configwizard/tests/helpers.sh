cat >> $HGRCPATH << EOF
[extensions]
configwizard = $TESTDIR/hgext/configwizard
EOF
